package com.RP.ControleDeJornada;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ControleDeJornadaApplicationTests {

	@Test
	void contextLoads() {
	}

}
